import React, { useEffect, useState } from "react";
import { Container, Row, Col, Dropdown } from "react-bootstrap";


import Select from "react-select";
import { useHistory } from "react-router-dom";
import { toast } from 'react-toastify';

import { addwhitelists } from "../../axioscalls/admin";
import config from '../../lib/config'
import useContractHook from "../../contract/contract";
import web3 from 'web3'
import { onInitialMint } from "../../axioscalls/token";
function Selectwhitelist() {

    const history = useHistory();
    const stylesgraybg = {
        option: (styles, { isFocused, isSelected, isHovered }) => ({
            ...styles,
            color: "#6C6A81",
            background: isFocused
                ? "#F5F6F7"
                : isSelected
                    ? "#F5F6F7"
                    : isHovered
                        ? "red"
                        : "#F5F6F7",

            zIndex: 1,
            cursor: "pointer",
            fontSize: "13px",
        }),

        option: (styles, { isFocused, isSelected, isHovered }) => {
            // const color = chroma(data.color);

            return {
                ...styles,
                backgroundColor: isHovered
                    ? "#16EBC3"
                    : isSelected
                        ? "#16EBC3"
                        : isFocused
                            ? "#16EBC3"
                            : "#151515",
                cursor: "pointer",
                color: isHovered
                    ? "#000"
                    : isSelected
                        ? "#000"
                        : isFocused
                            ? "#000"
                            : "#fff",
                fontSize: "13px",
            };
        },
        valueContainer: (provided, state) => ({
            ...provided,
            height: "40px",
            padding: "0 20px",
            backgroundColor: "#000 ",
            // border: "1px solid rgba(34, 34, 34, 0.32)",
            borderRadius: 5,
            fontSize: "13px",
        }),
        control: (provided, state) => ({
            ...provided,
            height: "40px",
            borderRadius: 5,
            // backgroundColor: "#fff",
            border: "none",
            outline: "none",
            boxShadow: "none",
        }),
        indicatorsContainer: (provided, state) => ({
            ...provided,
            height: "40px",
            position: "absolute",
            right: 0,
            top: 0,
            color: "#6C6A81",
        }),
        singleValue: (provided, state) => ({
            ...provided,
            color: "#6C6A81",
        }),
        menuList: (base) => ({
            ...base,
            // kill the white space on first and last option
            padding: 0,
        }),
    };
    const [projectArr, setProjectArr] = useState([])
    console.log("projectArr", projectArr);
    const [rewardOption, setRewardOption] = useState({});
    console.log("rewardOption", rewardOption);
    const [projectdata, setprojectdata] = useState([])
    console.log("projectdatass", projectdata);

    const contract = useContractHook()


    useEffect(() => {
        addwhitelists({ action: "getProjectsoption" })
            .then((val) => {
                setProjectArr(val.data ?? [])
            })
            .catch((e) => {
                console.log(" erro on getProjectsoption", e);
            })
    }, [])

    const handleSubmit = async (data) => {
        var dataproject = {
            projecttitle: data,
            action: "getAll"

        }
        console.log("dataprojectss", dataproject);
        var resp = await addwhitelists(dataproject);
        console.log("resssspppp", resp.data);
        setprojectdata(resp.data)
        // if (resp?.success == "success") {
        //     toast.success(resp?.msg)
        //       setTimeout(() => {
        //         history.goBack()
        //       }, 1000);

        // }
    }


    const onselect = async (nft) => {
        console.log("nfftt",nft);
        const params = {_id : nft?._id,mintCount:1
          }
      console.log("paramsms",params);
          const initialMint = await onInitialMint(params)
          console.log("initial min", initialMint);

          
        const Resp = await contract.adminlazyminting_721_1155(
                1,
                721,
                "BNB",
                web3.utils.toWei(nft?.NFTPrice.toString()),
                nft?.MetaData,
                [
                  1,
                  web3?.utils.toWei(nft?.NFTRoyalty),
                  nft.Nonce,
                  web3.utils.toWei(nft?.NFTPrice.toString()),
                ],
                [nft?.Randomname, "Coin"],
                nft?.Hash,
                [nft?.ContractAddress],
              )
              console.log("rtret3e3",Resp);
        
    }

    return (
        <>

            <Row className="select_holder">
                <Col lg={5}>
                    <Select
                        className="border_select"
                        placeholder="Project"
                        styles={stylesgraybg}
                        // defaultValue={selectedOption}
                        onChange={(e) => { setRewardOption({ ...rewardOption, projectsTitle: e._id }); handleSubmit(e._id) }}
                        options={projectArr}
                    />
                </Col>
                <div className="row gallery_img_sec">
                    <br />
                    {projectdata.map((val) => (
                        <>
                            {console.log("vvvlalllal", val.NFTName, val)}
                            <p>{val.NFTName}</p>
                            <div className="galley_images" onClick={() => onselect(val)}>
                                {(
                                    val.CompressedFile &&
                                    <img

                                        src={
                                            val.CompressedFile ? typeof val.CompressedFile == "object" ? window.URL.createObjectURL(
                                                val.CompressedFile) : `${config.ImG}/nft/${val?.NFTCreator}/Original/${val.NFTOrginalImage}` : <></>}
                                    // `${config.IMG_URL}/nft/${Tokens_Detail.NFTCreator}/Original/${Tokens_Detail.OriginalFile}`
                                    //   style={{ height: 100, width: 100 }}
                                    />
                                )}

                            </div>
                            <br />
                            {/* { (
                                Formdata?.offerImage  &&
                                <img 
                                src={
                                  Formdata?.offerImage
                                    ? typeof Formdata?.offerImage == "object"
                                      ? window.URL.createObjectURL(
                                        Formdata?.offerImage
                                        )
                                      : `${config.IMG_URL}/coupon/ADMIN/${Formdata?.offerImage}`
                                    : <></>
                                }
                                width={50}
                                />
                           
                              )} */}
                        </>

                    ))}
                </div>

            </Row>

            {/* <div>
                <button className='btn mt-3 allbtn' onClick={() => handleSubmit()}>SUBMIT</button>

            </div> */}

        </>)
}

export default Selectwhitelist;
